$(document).ready(function(){
    $(".menu-principal").sticky({topSpacing:0});
  });
